import minilog from 'minilog';
minilog.enable();

export default minilog('scratch-paint');
