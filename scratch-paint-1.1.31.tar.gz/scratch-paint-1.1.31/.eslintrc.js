module.exports = {
    extends: ['scratch', 'scratch/es6', 'scratch/node']
};
